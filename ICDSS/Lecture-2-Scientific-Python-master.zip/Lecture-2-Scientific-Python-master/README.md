# Launch Notebook
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/Imperial-College-Data-Science-Society/Lecture-2-Scientific-Python/master)
